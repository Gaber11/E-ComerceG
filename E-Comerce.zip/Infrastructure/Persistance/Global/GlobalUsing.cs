﻿global using Domain.Entities;
global using Microsoft.EntityFrameworkCore;
global using Microsoft.EntityFrameworkCore.Metadata.Builders;
global using System.Reflection;
global using Domain.Contracts;
global using Persistance.Data;
global using System.Collections.Concurrent;
global using System.Text.Json;
