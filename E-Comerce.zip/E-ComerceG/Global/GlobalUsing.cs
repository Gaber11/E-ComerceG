﻿global using Microsoft.EntityFrameworkCore;
global using Domain.Contracts;
global using Persistance.Data;
global using E_ComerceG.Extentions;
global using System.Text.Json.Serialization;
global using E_ComerceG.MiddleWares;
global using Service_Abstraction;
global using Services;
global using Persistance.Data.Data_Seeding;
global using Persistance.Repositries;
global using E_ComerceG.Factories;
global using Microsoft.AspNetCore.Mvc;

