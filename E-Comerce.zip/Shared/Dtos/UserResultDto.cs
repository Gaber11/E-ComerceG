﻿
namespace Shared.Dtos
{
    public record UserResultDto(string DisplayName, string Token ,string Email)
    {

    }
}
