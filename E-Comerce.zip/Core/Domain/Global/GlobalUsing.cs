﻿global using Domain.Entities;
global using System.Linq.Expressions;
