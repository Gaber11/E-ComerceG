﻿global using Shared;
global using ServiceAbstraction;
