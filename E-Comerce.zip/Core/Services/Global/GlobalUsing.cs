﻿global using AutoMapper;
global using Domain.Contracts;
global using Domain.Entities;
global using ServiceAbstraction;
global using Shared;
global using Services.Specifications;
global using Service_Abstraction;
