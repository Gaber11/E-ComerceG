﻿
namespace Services
{
    public class AssemblyReference
    {
    }
}
